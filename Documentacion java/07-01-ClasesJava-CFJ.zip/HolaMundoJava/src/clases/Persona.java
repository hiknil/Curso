package clases;

public class Persona {
    
}
