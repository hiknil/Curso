package clases;

public class Persona {
    //Atributos de la clase
    String nombre;
    String apellido;
    
    //Metodos de la clase
    public void desplegarInformacion(){
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
    }
}
