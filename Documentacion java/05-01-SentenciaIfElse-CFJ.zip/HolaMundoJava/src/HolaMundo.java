
//Mi clase en Java
public class HolaMundo {

    public static void main(String args[]) {
        var condicion = true;

        if (condicion) {
            System.out.println("Condicion verdadera");
        } else {
            System.out.println("Condicion falsa");
        }
    }
}
